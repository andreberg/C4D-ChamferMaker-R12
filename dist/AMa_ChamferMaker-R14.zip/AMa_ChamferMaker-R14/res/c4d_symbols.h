enum
{
	IDS_AMaChamferMAKER_MENU_NAME	= 10000,
	_DUMMY_
};
